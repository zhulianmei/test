function thread_init(thread_id)
   db_connect()
end

function event(thread_id)
   local table_name
   local rs
   table_name = "sbtest1"
   tb_value=string.rep("(null,50417,'43673157147-91336335899-31225656964-29549245002-32601329195-47347369500-56617392521-84167554354-62914038884-31079546054','29277435315-19646337537-48947866013-18112182363-64357784712'),",4)
   tb_value=string.sub(tb_value,0,-2)
   rs=db_query("insert into sbtest1 values" .. tb_value ..";")
end
